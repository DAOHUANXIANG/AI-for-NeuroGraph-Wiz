import { GoogleGenAI, Type, Schema } from "@google/genai";
import { GraphData, ChatMessage, ChatResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
const MODEL_NAME = "gemini-2.5-flash";

// Shared Schema definitions
const nodeSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    id: { type: Type.STRING, description: "Unique identifier for the node" },
    label: { type: Type.STRING, description: "Display name (e.g., 'conv1', 'fc2', '卷积层1')" },
    type: { type: Type.STRING, description: "Layer type (e.g., 'Conv2d')" },
    description: { type: Type.STRING, description: "Details like kernel size or channels (e.g., '3x3, 64')" },
    suggestedColor: { type: Type.STRING, description: "Hex color code" },
  },
  required: ["id", "label", "type"],
};

const edgeSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    source: { type: Type.STRING, description: "ID of the source node" },
    target: { type: Type.STRING, description: "ID of the target node" },
    label: { type: Type.STRING, description: "Optional label for the connection (e.g., tensor shape)" },
  },
  required: ["source", "target"],
};

const graphSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    nodes: { type: Type.ARRAY, items: nodeSchema },
    edges: { type: Type.ARRAY, items: edgeSchema },
  },
  required: ["nodes", "edges"],
};

export const analyzeCodeAndGenerateGraph = async (code: string): Promise<GraphData> => {
  const prompt = `
    You are an expert Deep Learning Engineer and Visualization Specialist.
    Your task is to analyze the provided Python code and extract the model architecture as a directed graph for an SCI paper.

    Context: The code may contain multiple files. Treat them as a unified project.
    
    1. Identify the MAIN model architecture.
    2. Extract layers as 'nodes' and data flow as 'edges'.
    3. Suggest professional colors for nodes (Blue for Conv, Green for Linear, etc.).
    4. If the code implies a specific structure (ResNet, UNet), ensure edges reflect skip connections.

    Code to analyze:
    \`\`\`python
    ${code.substring(0, 30000)}
    \`\`\`
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: graphSchema,
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    return JSON.parse(text) as GraphData;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to analyze code.");
  }
};

export const processChatInteraction = async (
  code: string,
  currentGraph: GraphData | null,
  history: ChatMessage[],
  userMessage: string
): Promise<ChatResponse> => {
  
  const conversationHistory = history.map(h => `${h.role === 'user' ? 'User' : 'Assistant'}: ${h.text}`).join('\n');
  
  const prompt = `
    You are an intelligent AI Assistant in a software called "NeuroGraph Wiz".
    You have access to the user's Python code and the currently rendered Graph Visualization.

    Task:
    Analyze the User's Message and decide on the action:
    
    1. **Question Answering**: If the user asks a question about the code or model (e.g., "What is the input size?", "Explain the residual block"), provide a clear, helpful text answer. Set 'updatedGraph' to null.
    
    2. **Graph Modification**: If the user asks to CHANGE the visualization (e.g., "Change labels to Chinese", "Make conv layers red", "Simplify the graph", "Show me the attention heads"), you MUST:
       - Generate a NEW 'updatedGraph' object based on the 'currentGraph' but applying the user's changes.
       - Provide a short 'answer' confirming the change.
       - For translations (e.g. "English to Chinese"): Translate 'label' and 'description' fields.
       - For styling: Update 'suggestedColor'.

    Context Data:
    
    [Current Graph JSON]:
    ${JSON.stringify(currentGraph || "No graph generated yet")}

    [User Code Snippet]:
    ${code.substring(0, 10000)}... (truncated)

    [Conversation History]:
    ${conversationHistory}

    [User's New Message]:
    ${userMessage}
  `;

  const chatResponseSchema: Schema = {
    type: Type.OBJECT,
    properties: {
      answer: { type: Type.STRING, description: "The text response to the user." },
      updatedGraph: { 
        ...graphSchema, 
        nullable: true, 
        description: "The new graph data if modifications are needed, otherwise null." 
      },
    },
    required: ["answer"],
  };

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: chatResponseSchema,
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response");
    return JSON.parse(text) as ChatResponse;
  } catch (error) {
    console.error("Chat Error:", error);
    return { answer: "Sorry, I encountered an error processing your request." };
  }
};
