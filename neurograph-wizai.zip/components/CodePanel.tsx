import React, { useRef, useState } from 'react';
import { Code2, Play, Upload, FileText, Trash2, Plus } from 'lucide-react';

interface CodePanelProps {
  code: string;
  setCode: React.Dispatch<React.SetStateAction<string>>;
  onGenerate: () => void;
  isGenerating: boolean;
}

const CodePanel: React.FC<CodePanelProps> = ({ code, setCode, onGenerate, isGenerating }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileList, setFileList] = useState<string[]>([]);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    const newFileNames: string[] = [];
    const readPromises: Promise<string>[] = [];

    Array.from(files).forEach(file => {
      newFileNames.push(file.name);
      
      const promise = new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = (e) => {
          const content = e.target?.result as string;
          let processedContent = content;

          if (file.name.endsWith('.ipynb')) {
            try {
              const json = JSON.parse(content);
              processedContent = json.cells
                .filter((cell: any) => cell.cell_type === 'code')
                .map((cell: any) => (Array.isArray(cell.source) ? cell.source.join('') : cell.source))
                .join('\n');
            } catch (err) {
              processedContent = `# Error parsing ${file.name}`;
            }
          }
          
          resolve(`# ==========================================\n# FILE: ${file.name}\n# ==========================================\n${processedContent}\n\n`);
        };
        reader.readAsText(file);
      });
      readPromises.push(promise);
    });

    Promise.all(readPromises).then((contents) => {
      const combinedCode = contents.join('');
      // If code is default or empty, replace it. Otherwise append.
      if (code.includes('class SimpleNet') && code.length < 500) {
         setCode(combinedCode);
      } else {
         setCode(prev => prev + combinedCode);
      }
      setFileList(prev => [...prev, ...newFileNames]);
    });
    
    // Reset
    event.target.value = '';
  };

  const clearCode = () => {
    setCode('');
    setFileList([]);
  };

  return (
    <div className="flex flex-col h-full bg-gray-900 border-r border-gray-800 shadow-xl w-full">
      {/* Toolbar */}
      <div className="flex flex-col border-b border-gray-700 bg-gray-800">
        <div className="flex items-center justify-between px-4 py-3">
            <div className="flex items-center space-x-2 text-blue-400">
            <Code2 size={20} />
            <span className="font-semibold text-gray-100">Project Code</span>
            </div>
            
            <button
            onClick={onGenerate}
            disabled={isGenerating}
            className={`flex items-center space-x-2 px-4 py-1.5 rounded-md text-sm font-medium transition-all ${
                isGenerating
                ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white shadow-lg'
            }`}
            >
            {isGenerating ? (
                <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Analyzing...</span>
                </>
            ) : (
                <>
                <Play size={16} fill="currentColor" />
                <span>Analyze & Draw</span>
                </>
            )}
            </button>
        </div>

        {/* File Actions */}
        <div className="flex items-center gap-2 px-4 pb-2">
           <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".py,.ipynb,.txt"
            multiple // Allow multiple files
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-gray-700 hover:bg-gray-600 text-gray-200 text-xs rounded border border-gray-600 transition-colors"
          >
            <Upload size={14} />
            <span>Upload Files (.py/.ipynb)</span>
          </button>
          
          <button
            onClick={clearCode}
            className="px-3 py-2 bg-gray-700 hover:bg-red-900/50 hover:border-red-800 text-gray-400 hover:text-red-200 text-xs rounded border border-gray-600 transition-colors"
            title="Clear All"
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>

      {/* File List Indicator */}
      {fileList.length > 0 && (
        <div className="px-4 py-2 bg-gray-800/50 border-b border-gray-700 overflow-x-auto whitespace-nowrap custom-scrollbar">
            <div className="flex gap-2">
                {fileList.map((f, i) => (
                    <span key={i} className="inline-flex items-center px-2 py-1 rounded bg-gray-700 text-xs text-blue-300 border border-gray-600">
                        <FileText size={10} className="mr-1" />
                        {f}
                    </span>
                ))}
            </div>
        </div>
      )}

      <div className="flex-1 relative group">
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className="w-full h-full bg-[#111827] text-gray-300 font-mono text-xs p-4 resize-none focus:outline-none custom-scrollbar leading-relaxed"
          placeholder="# Paste your Python code here OR upload multiple files."
          spellCheck={false}
        />
        <div className="absolute bottom-2 right-4 text-[10px] text-gray-600 pointer-events-none">
            {code.length} chars
        </div>
      </div>
      
      <div className="px-4 py-2 bg-gray-800 text-[10px] text-gray-500 border-t border-gray-700 flex justify-between">
        <span>Model: Gemini 2.5 Flash</span>
        <span>Multi-file Support Active</span>
      </div>
    </div>
  );
};

export default CodePanel;