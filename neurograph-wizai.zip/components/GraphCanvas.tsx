import React, { useCallback, useEffect, useState, useRef } from 'react';
import ReactFlow, {
  Node,
  Edge,
  Background,
  Controls,
  Connection,
  addEdge,
  useNodesState,
  useEdgesState,
  MarkerType,
  BackgroundVariant,
  ReactFlowProvider,
  useReactFlow,
} from 'reactflow';
import { toPng, toSvg } from 'html-to-image';
import { Download, Sun, Moon, ArrowRight, ArrowDown, Image as ImageIcon, FileCode } from 'lucide-react';
import NodeCustomizer from './NodeCustomizer';
import { GraphData } from '../types';

interface GraphCanvasProps {
  graphData: GraphData | null;
}

type Theme = 'dark' | 'light';
type Direction = 'TB' | 'LR';

// Initial placeholder
const initialNodes: Node[] = [
  {
    id: 'placeholder-1',
    position: { x: 250, y: 100 },
    data: { label: 'Paste Code' },
    style: { background: '#374151', color: '#fff', border: '1px solid #4B5563', width: 150 },
  },
  {
    id: 'placeholder-2',
    position: { x: 250, y: 200 },
    data: { label: 'Click Generate' },
    style: { background: '#1f2937', color: '#9CA3AF', border: '1px solid #374151', width: 150 },
  },
];
const initialEdges: Edge[] = [
  { id: 'e1-2', source: 'placeholder-1', target: 'placeholder-2', animated: true, style: { stroke: '#4B5563' } }
];

const GraphCanvasContent: React.FC<GraphCanvasProps> = ({ graphData }) => {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  
  // Customization State
  const [theme, setTheme] = useState<Theme>('light'); // Default to light for SCI papers
  const [direction, setDirection] = useState<Direction>('TB');
  
  // Reference for export
  const reactFlowWrapper = useRef<HTMLDivElement>(null);
  const { getNodes } = useReactFlow();

  // Helper to generate styles based on theme
  const getNodeStyle = useCallback((suggestedColor?: string) => {
    if (theme === 'light') {
      return {
        background: suggestedColor || '#ffffff',
        color: '#000000',
        border: '2px solid #000000', // Strong border for papers
        padding: '10px',
        borderRadius: '4px', // Sharper corners for technical look
        minWidth: '150px',
        textAlign: 'center',
        fontWeight: 'bold',
        boxShadow: 'none', // Flat design for print
        fontSize: '14px',
        fontFamily: '"Times New Roman", Times, serif', // Serif font is common in papers
      };
    } else {
      return {
        background: suggestedColor || '#374151',
        color: '#fff',
        border: '1px solid rgba(255,255,255,0.2)',
        padding: '10px',
        borderRadius: '8px',
        minWidth: '150px',
        textAlign: 'center',
        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
        fontSize: '14px',
        fontFamily: 'ui-sans-serif, system-ui, sans-serif',
      };
    }
  }, [theme]);

  const getEdgeStyle = useCallback(() => {
    if (theme === 'light') {
      return { stroke: '#000000', strokeWidth: 2 };
    } else {
      return { stroke: '#60A5FA', strokeWidth: 2 };
    }
  }, [theme]);

  // Apply Graph Data when it changes or when styling options change
  useEffect(() => {
    if (graphData) {
      const nodeSpacing = 120;
      
      const newNodes: Node[] = graphData.nodes.map((n, index) => {
        // Simple auto-layout calculation
        const x = direction === 'LR' ? 50 + index * 180 : 250;
        const y = direction === 'LR' ? 250 : 50 + index * nodeSpacing;

        return {
          id: n.id,
          position: { x, y },
          data: { 
            label: n.label, 
            description: n.description,
            type: n.type,
            color: n.suggestedColor 
          },
          // @ts-ignore
          style: getNodeStyle(n.suggestedColor),
        };
      });

      const newEdges: Edge[] = graphData.edges.map((e) => ({
        id: `e-${e.source}-${e.target}`,
        source: e.source,
        target: e.target,
        label: e.label,
        type: 'smoothstep', // nice connector style
        animated: theme === 'dark', // Disable animation for print/paper view
        style: getEdgeStyle(),
        markerEnd: {
            type: MarkerType.ArrowClosed,
            color: theme === 'light' ? '#000000' : '#60A5FA',
        },
        labelStyle: { fill: theme === 'light' ? '#000' : '#fff', fontWeight: 700 },
        labelBgStyle: { fill: theme === 'light' ? '#fff' : '#1f2937', fillOpacity: 0.8 },
      }));

      setNodes(newNodes);
      setEdges(newEdges);
    }
  }, [graphData, setNodes, setEdges, theme, direction, getNodeStyle, getEdgeStyle]);

  // Re-apply styles if theme changes without data change (for existing nodes)
  useEffect(() => {
    setNodes((nds) => nds.map(node => ({
      ...node,
      style: {
        ...getNodeStyle(node.data.color),
        // Preserve position
      }
    })));
    setEdges((eds) => eds.map(edge => ({
      ...edge,
      style: getEdgeStyle(),
      markerEnd: {
          type: MarkerType.ArrowClosed,
          color: theme === 'light' ? '#000000' : '#60A5FA',
      },
      animated: theme === 'dark',
      labelStyle: { fill: theme === 'light' ? '#000' : '#fff', fontWeight: 700 },
      labelBgStyle: { fill: theme === 'light' ? '#fff' : '#1f2937', fillOpacity: 0.8 },
    })));
  }, [theme, getNodeStyle, getEdgeStyle, setNodes, setEdges]);


  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  const onNodeClick = useCallback((event: React.MouseEvent, node: Node) => {
    setSelectedNode(node);
  }, []);

  const onPaneClick = useCallback(() => {
    setSelectedNode(null);
  }, []);

  const handleNodeUpdate = (id: string, updates: any) => {
    setNodes((nds) =>
      nds.map((node) => {
        if (node.id === id) {
          const newData = { ...node.data };
          
          if (updates.label) newData.label = updates.label;
          if (updates.description) newData.description = updates.description;
          if (updates.color) newData.color = updates.color;
          
          return { 
            ...node, 
            data: newData, 
            style: { ...node.style, background: updates.color || node.style?.background }
          };
        }
        return node;
      })
    );
    
    setSelectedNode(prev => prev ? { 
        ...prev, 
        data: {...prev.data, ...updates}, 
        style: {...prev.style, ...(updates.color ? {background: updates.color} : {})} 
    } : null);
  };

  const downloadImage = (format: 'png' | 'svg') => {
    if (reactFlowWrapper.current === null) {
      return;
    }

    const exportFn = format === 'png' ? toPng : toSvg;
    
    // We filter out the 'react-flow__controls' and minime 'react-flow__attribution' to make it clean
    const filter = (node: HTMLElement) => {
      const exclusionClasses = ['react-flow__controls', 'react-flow__attribution'];
      return !exclusionClasses.some((classname) => node.classList?.contains(classname));
    };

    exportFn(reactFlowWrapper.current, { backgroundColor: theme === 'light' ? '#ffffff' : '#030712', filter, pixelRatio: 3 })
      .then((dataUrl) => {
        const link = document.createElement('a');
        link.download = `neurograph-wiz-architecture.${format}`;
        link.href = dataUrl;
        link.click();
      })
      .catch((err) => {
        console.error('Export failed:', err);
      });
  };

  return (
    <div className={`w-full h-full relative ${theme === 'light' ? 'bg-white' : 'bg-gray-950'}`} ref={reactFlowWrapper}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onNodeClick={onNodeClick}
        onPaneClick={onPaneClick}
        fitView
      >
        <Background 
            variant={BackgroundVariant.Dots} 
            gap={12} 
            size={1} 
            color={theme === 'light' ? '#e5e7eb' : '#374151'} 
        />
        <Controls className={theme === 'light' ? 'bg-white border-gray-200 text-gray-800' : 'bg-gray-800 border-gray-700 fill-gray-200 text-gray-200'} />
      </ReactFlow>

      {/* Toolbar */}
      <div className="absolute top-4 left-4 flex flex-col gap-2 z-10">
        <div className={`flex items-center p-1 rounded-lg border shadow-lg backdrop-blur-sm ${theme === 'light' ? 'bg-white/90 border-gray-200' : 'bg-gray-900/90 border-gray-700'}`}>
           <button 
             onClick={() => setTheme('light')} 
             className={`p-2 rounded ${theme === 'light' ? 'bg-blue-100 text-blue-700' : 'text-gray-400 hover:text-white'}`}
             title="SCI Paper Mode (Light)"
           >
             <Sun size={18} />
           </button>
           <button 
             onClick={() => setTheme('dark')} 
             className={`p-2 rounded ${theme === 'dark' ? 'bg-blue-900/50 text-blue-400' : 'text-gray-500 hover:text-gray-800'}`}
             title="Dark Mode"
           >
             <Moon size={18} />
           </button>
        </div>

        <div className={`flex items-center p-1 rounded-lg border shadow-lg backdrop-blur-sm ${theme === 'light' ? 'bg-white/90 border-gray-200' : 'bg-gray-900/90 border-gray-700'}`}>
           <button 
             onClick={() => setDirection('TB')} 
             className={`p-2 rounded ${direction === 'TB' ? (theme === 'light' ? 'bg-blue-100 text-blue-700' : 'bg-blue-900/50 text-blue-400') : (theme === 'light' ? 'text-gray-500' : 'text-gray-400')}`}
             title="Vertical Layout"
           >
             <ArrowDown size={18} />
           </button>
           <button 
             onClick={() => setDirection('LR')} 
             className={`p-2 rounded ${direction === 'LR' ? (theme === 'light' ? 'bg-blue-100 text-blue-700' : 'bg-blue-900/50 text-blue-400') : (theme === 'light' ? 'text-gray-500' : 'text-gray-400')}`}
             title="Horizontal Layout"
           >
             <ArrowRight size={18} />
           </button>
        </div>

        <div className={`flex items-center gap-1 p-1 rounded-lg border shadow-lg backdrop-blur-sm ${theme === 'light' ? 'bg-white/90 border-gray-200' : 'bg-gray-900/90 border-gray-700'}`}>
            <button
                onClick={() => downloadImage('png')}
                className={`p-2 rounded flex items-center gap-2 text-xs font-semibold ${theme === 'light' ? 'text-gray-700 hover:bg-gray-100' : 'text-gray-200 hover:bg-gray-800'}`}
                title="Export PNG"
            >
                <ImageIcon size={16} />
                PNG
            </button>
            <div className={`w-px h-4 ${theme === 'light' ? 'bg-gray-300' : 'bg-gray-700'}`}></div>
            <button
                onClick={() => downloadImage('svg')}
                className={`p-2 rounded flex items-center gap-2 text-xs font-semibold ${theme === 'light' ? 'text-gray-700 hover:bg-gray-100' : 'text-gray-200 hover:bg-gray-800'}`}
                title="Export SVG (Best for Papers)"
            >
                <FileCode size={16} />
                SVG
            </button>
        </div>
      </div>

      <NodeCustomizer 
        selectedNode={selectedNode} 
        onClose={() => setSelectedNode(null)} 
        onUpdate={handleNodeUpdate} 
      />

      {/* Legend / Instructions */}
      <div className={`absolute bottom-4 left-4 p-3 rounded-lg text-xs border pointer-events-none ${theme === 'light' ? 'bg-white/90 border-gray-200 text-gray-600' : 'bg-gray-900/90 border-gray-700 text-gray-400'}`}>
        <p className={`font-semibold mb-1 ${theme === 'light' ? 'text-gray-900' : 'text-gray-200'}`}>Controls:</p>
        <ul className="space-y-1">
          <li>• Click node to edit text & color</li>
          <li>• Drag nodes to fine-tune positions</li>
          <li>• Use toolbar to switch to "Paper Mode"</li>
          <li>• Export as SVG for maximum quality</li>
        </ul>
      </div>
    </div>
  );
};

// Wrap in provider to ensure context exists if we use hooks that need it
const GraphCanvas: React.FC<GraphCanvasProps> = (props) => (
  <ReactFlowProvider>
    <GraphCanvasContent {...props} />
  </ReactFlowProvider>
);

export default GraphCanvas;