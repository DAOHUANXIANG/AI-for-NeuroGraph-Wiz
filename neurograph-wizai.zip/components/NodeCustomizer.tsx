import React from 'react';
import { X, Type, Palette, AlignLeft } from 'lucide-react';
import { Node } from 'reactflow';

interface NodeCustomizerProps {
  selectedNode: Node | null;
  onClose: () => void;
  onUpdate: (id: string, data: any) => void;
}

const NodeCustomizer: React.FC<NodeCustomizerProps> = ({ selectedNode, onClose, onUpdate }) => {
  if (!selectedNode) return null;

  // Helper to extract data safely
  const data = selectedNode.data || {};
  const bgColor = selectedNode.style?.background || data.color || '#374151';

  const handleChange = (field: string, value: string) => {
    // We update 'data' for label/desc, but 'style' for color logic usually.
    // However, to keep it simple, we will pass everything back to parent to handle the React Flow specific structure.
    onUpdate(selectedNode.id, { [field]: value });
  };

  return (
    <div className="absolute top-4 right-4 w-72 bg-gray-800 border border-gray-700 rounded-lg shadow-2xl z-50 animate-in fade-in slide-in-from-right-10 duration-200">
      <div className="flex items-center justify-between p-3 border-b border-gray-700">
        <h3 className="font-semibold text-gray-200">Edit Module</h3>
        <button onClick={onClose} className="text-gray-400 hover:text-white">
          <X size={16} />
        </button>
      </div>
      
      <div className="p-4 space-y-4">
        {/* Label Input */}
        <div className="space-y-1">
          <label className="flex items-center text-xs font-medium text-gray-400">
            <Type size={12} className="mr-1.5" />
            Module Name
          </label>
          <input
            type="text"
            value={data.label || ''}
            onChange={(e) => handleChange('label', e.target.value)}
            className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1.5 text-sm text-gray-200 focus:border-blue-500 focus:outline-none"
          />
        </div>

        {/* Description Input */}
        <div className="space-y-1">
          <label className="flex items-center text-xs font-medium text-gray-400">
            <AlignLeft size={12} className="mr-1.5" />
            Details (e.g., Kernel)
          </label>
          <input
            type="text"
            value={data.description || ''}
            onChange={(e) => handleChange('description', e.target.value)}
            className="w-full bg-gray-900 border border-gray-700 rounded px-2 py-1.5 text-sm text-gray-200 focus:border-blue-500 focus:outline-none"
          />
        </div>

        {/* Color Picker */}
        <div className="space-y-1">
          <label className="flex items-center text-xs font-medium text-gray-400">
            <Palette size={12} className="mr-1.5" />
            Background Color
          </label>
          <div className="flex items-center space-x-2">
            <input
              type="color"
              value={typeof bgColor === 'string' ? bgColor : '#374151'}
              onChange={(e) => handleChange('color', e.target.value)}
              className="w-8 h-8 rounded cursor-pointer bg-transparent border-none"
            />
            <span className="text-xs text-gray-500 font-mono">
              {typeof bgColor === 'string' ? bgColor : '#374151'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NodeCustomizer;
