import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, Sparkles, RefreshCw } from 'lucide-react';
import { ChatMessage, GraphData } from '../types';
import { processChatInteraction } from '../services/geminiService';

interface ChatPanelProps {
  code: string;
  graphData: GraphData | null;
  onGraphUpdate: (newData: GraphData) => void;
}

const ChatPanel: React.FC<ChatPanelProps> = ({ code, graphData, onGraphUpdate }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: 'Hello! I am your research assistant. I can help you understand the model architecture or modify the graph. \n\nTry asking: "Translate labels to Chinese" or "Highlight the encoder layers in red".' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: ChatMessage = { role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      // Use the new smart process function
      const response = await processChatInteraction(code, graphData, messages, input);
      
      const botMsg: ChatMessage = { role: 'model', text: response.answer };
      setMessages(prev => [...prev, botMsg]);

      // If the AI decided to update the graph, apply it
      if (response.updatedGraph) {
        onGraphUpdate(response.updatedGraph);
        setMessages(prev => [...prev, { role: 'model', text: '🎨 Graph updated according to your request.' }]);
      }

    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: "Sorry, I'm having trouble connecting to the AI brain right now." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-full bg-gray-900 border-l border-gray-800 shadow-xl w-full">
        <div className="flex items-center justify-between px-4 py-3 bg-gray-800 border-b border-gray-700">
            <div className="flex items-center">
                <div className="p-1 bg-gradient-to-tr from-purple-600 to-blue-600 rounded-md mr-2 shadow-lg shadow-purple-900/50">
                    <Sparkles size={16} className="text-white" />
                </div>
                <span className="font-semibold text-gray-100 text-sm tracking-wide">AI Copilot</span>
            </div>
            {isLoading && <RefreshCw size={14} className="animate-spin text-gray-500" />}
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar bg-gray-950/50">
            {messages.map((msg, idx) => (
                <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] rounded-2xl p-3.5 text-sm leading-relaxed shadow-sm ${
                        msg.role === 'user' 
                        ? 'bg-blue-600 text-white rounded-br-none shadow-blue-900/20' 
                        : 'bg-gray-800 text-gray-200 rounded-bl-none border border-gray-700/50'
                    }`}>
                       {msg.role === 'model' && <Bot size={14} className="mb-2 text-purple-400" />} 
                       <div className="whitespace-pre-wrap">{msg.text}</div>
                    </div>
                </div>
            ))}
            {isLoading && (
                <div className="flex justify-start">
                    <div className="bg-gray-800 rounded-2xl rounded-bl-none p-4 border border-gray-700/50">
                        <div className="flex space-x-1.5">
                            <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" />
                            <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce delay-75" />
                            <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce delay-150" />
                        </div>
                    </div>
                </div>
            )}
            <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 bg-gray-900 border-t border-gray-800">
            <div className="relative flex items-center shadow-lg rounded-full bg-gray-800 border border-gray-700 focus-within:border-blue-500 focus-within:ring-1 focus-within:ring-blue-500 transition-all">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Ask to modify graph (e.g. 'Use Chinese labels')..."
                    className="w-full bg-transparent text-gray-200 text-sm py-3 pl-5 pr-12 focus:outline-none placeholder-gray-500"
                    disabled={isLoading}
                />
                <button 
                    onClick={handleSend}
                    disabled={isLoading || !input.trim()}
                    className="absolute right-2 p-2 bg-blue-600 hover:bg-blue-500 text-white rounded-full disabled:bg-gray-700 disabled:text-gray-500 transition-colors shadow-md"
                >
                    <Send size={16} />
                </button>
            </div>
            {!code && (
                <p className="text-[10px] text-yellow-500/80 mt-2 text-center font-medium">Please provide code first.</p>
            )}
        </div>
    </div>
  );
};

export default ChatPanel;
